<p><img  src="./app/assets/images/logo.png" height="130px" alt="hariona"></p>

<h1>hariona Launcher</h1>

<p>
    <img src="https://img.shields.io/badge/version-1.2.0-dark_green.svg?style=for-the-badge" alt="version">
</p>

---

<p>
    Basé sur le travail de Daniel Scalzi (https://github.com/dscalzi/HeliosLauncher)
</p>

---
