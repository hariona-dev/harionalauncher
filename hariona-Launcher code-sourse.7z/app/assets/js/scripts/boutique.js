document.getElementById('home').addEventListener('click', e => {
    switchView(VIEWS.boutique, VIEWS.landing)
})
